<?php include 'include/inc_header1.php';?>

<?php include 'include/inc_sidebar2.php';?>

<main class="vt-main">
<section>
            <img src="<?php echo base_url();?>/assets/img/blogbanner.png" class="img-fluid" alt="">
        </section>
        
        
        
       <section class="vt-blog-bg">
            <div class="container text-center" >
                  <div class="row">
                    <div class="col-md-12">
                    <ul class="nav nav-pills nav-justified mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="btn active btn-outline-primary btn-lg" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Interactive</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="btn btn-outline-primary btn-lg" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Scenario based</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="btn btn-outline-primary btn-lg" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Gamified</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="btn btn-outline-primary btn-lg" id="pills-Video-tab" data-bs-toggle="pill" data-bs-target="#pills-video" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Video-based</button>
                        </li>
                    </ul>
        <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
            <div class="row">
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-09.png" alt="" class="img-fluid"/></div>
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-10.png" alt="" class="img-fluid"/></div>
            </div><br>
            <div class="row">
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-11.png" alt="" class="img-fluid"/></div>
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-12.png" alt="" class="img-fluid"/></div>
            </div><br>
            <div class="row">
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-13.png" alt="" class="img-fluid"/></div>
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-14.png" alt="" class="img-fluid"/></div>
            </div><br>
        </div>
        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
        <div class="row">
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-11.png" alt="" class="img-fluid"/></div>
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-12.png" alt="" class="img-fluid"/></div>
            </div><br>
            <div class="row">
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-13.png" alt="" class="img-fluid"/></div>
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-14.png" alt="" class="img-fluid"/></div>
            </div><br>
        </div>
        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
        
            <div class="row">
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-13.png" alt="" class="img-fluid"/></div>
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-14.png" alt="" class="img-fluid"/></div>
            </div><br>
        </div>
        <div class="tab-pane fade" id="pills-video" role="tabpanel" aria-labelledby="pills-video-tab">
        <div class="row">
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-11.png" alt="" class="img-fluid"/></div>
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-12.png" alt="" class="img-fluid"/></div>
            </div><br>
            <div class="row">
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-13.png" alt="" class="img-fluid"/></div>
                <div class="col-md-6"><img src="<?php echo base_url();?>/assets/img/OurSuccessStories_2-14.png" alt="" class="img-fluid"/></div>
            </div><br>
        </div>
        </div>
                    </div>
                  </div>
                </div> 
                <div class="container" > 
                
                
                
                 </div>
            
       </section>

<?php include 'include/inc_footer3.php';?>
</main>
<?php include 'include/inc_bottom4.php';?>